import smbus

bus = smbus.SMBus(1)  # or 0 for older Raspberry Pi models
for address in range(0, 128):
    try:
        bus.read_byte(address)
        print(f"I2C device found at address 0x{address:02x}")
    except:
        pass

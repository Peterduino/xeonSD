#Imports
import RPi.GPIO as GPIO
import time

#Setup
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#Defining functions
def set_background_color(color):
    if color == "red":
        print("\033[41m\033[2J\033[H", end='')
    elif color == "green":
        print("\033[42m\033[2J\033[H", end='')

#Stting pins
switch_pin = 26
dual1 = 6
dual2 = 5

#GPIO setups
GPIO.setup(dual1,GPIO.OUT)
GPIO.setup(dual2,GPIO.OUT)
GPIO.setup(switch_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)


#Initial GPIO states
GPIO.output(dual1,GPIO.LOW)


#Code

"""print("Dual on")
GPIO.output(dual2,GPIO.HIGH)

time.sleep(4)

print("Dual off")
GPIO.output(dual2,GPIO.LOW)
"""

try:
    current_color = None
    while True:
        switch_state = GPIO.input(switch_pin)

        if True : # switch_state == GPIO.HIGH:
            if current_color != "green":
                set_background_color("green")
                current_color = "green"
                print("Switch is ON")
                GPIO.output(dual2,GPIO.HIGH)
        else:
            if current_color != "red":
                set_background_color("red")
                current_color = "red"
                print("Switch is OFF")
                GPIO.output(dual2,GPIO.LOW)


        # Wait for a short period before checking again
        time.sleep(0.1)

except KeyboardInterrupt:
    GPIO.cleanup()
    print("\033[0m")

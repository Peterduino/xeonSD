import RPi.GPIO as GPIO
import time

# Define the GPIO pins
LED_PINS = [20, 21, 16, 12, 23]
optoPIN = 22

# Set up GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Set up outputs
for pin in LED_PINS:
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.LOW)
GPIO.setup(optoPIN, GPIO.IN)

def wave_animation(delay=0.1, cycles=10):
    for _ in range(cycles):
        # Turn on each LED one by one
        for pin in LED_PINS:
            GPIO.output(pin, GPIO.HIGH)
            time.sleep(delay)
            GPIO.output(pin, GPIO.LOW)

        # Turn off each LED one by one
        for pin in reversed(LED_PINS):
            GPIO.output(pin, GPIO.HIGH)
            time.sleep(delay)
            GPIO.output(pin, GPIO.LOW)

try:
    while True:
        if GPIO.input(optoPIN)==1:
            time.sleep(1)
            if GPIO.input(optoPIN)==1:
                wave_animation(delay=0.075, cycles=200)
except KeyboardInterrupt:
    pass
finally:
    # Clean up GPIO settings
    GPIO.cleanup()

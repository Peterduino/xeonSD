#Imports
import RPi.GPIO as GPIO
import time

#Setup
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#Defining functions
def set_background_color(color):
    if color == "red":
        print("\033[41m\033[2J\033[H", end='')
    elif color == "green":
        print("\033[42m\033[2J\033[H", end='')

#Stting pins
optoIn1 = 17
optoIn2 = 22
optoOt1 = 27
optoOt2 = 4

led1 = 20
led2 = 16
led3 = 56

#GPIO setups
GPIO.setup(optoOt1, GPIO.OUT)
GPIO.setup(optoOt2, GPIO.OUT)
GPIO.setup(optoIn1, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(optoIn2, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

GPIO.setup(led1, GPIO.OUT)
GPIO.setup(led2, GPIO.OUT)

#GPIO.setup(switch_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)


#Initial GPIO states
#GPIO.output(dual2,GPIO.HIGH)
#time.sleep(30)
#GPIO.output(dual2,GPIO.LOW)

currentStateOut = GPIO.HIGH

while True:
    currentStateOut = GPIO.HIGH if currentStateOut==GPIO.LOW else GPIO.LOW
    GPIO.output(optoOt1, currentStateOut)
    GPIO.output(optoOt2, currentStateOut)

    in1 = GPIO.input(optoIn1)
    in2 = GPIO.input(optoIn2)

    if in1==1: GPIO.output(led1, GPIO.HIGH)
    else : GPIO.output(led1, GPIO.LOW)

    if in2==1: GPIO.output(led2, GPIO.HIGH)
    else : GPIO.output(led2, GPIO.LOW)

    print(f"OUTs : {currentStateOut} ; IN 1 : {in1} ; IN 2 : {in2}")
    time.sleep(1)
GPIO.cleanup()

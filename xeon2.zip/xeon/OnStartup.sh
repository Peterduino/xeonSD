# Everything here will normally be executed at startup

#mpg123 kkk2.mp3
#sudo python3 sound.py

mpg123 audio.mp3 &
#sudo python3 /home/xeon/flight2/main.py
#sudo python3 Xeon/main.py &
#sudo python3 xenophobe/main.py &
#sudo python3 xoxo/GPSinc.py &
#sudo python3 hegaldi/drl.py &
#sudo python3 hegaldi/grl.py &
#python3 arnaudProst2.py &
#python3 arnaudProst3.py &
